# The Board — Campus Events Dashboard

A single self-contained HTML page (`index.html`) for tracking campus events that would otherwise
only get announced in WhatsApp groups.

## What's inside
- Event board with search/filters (category, club, date range) and a calendar view
- Event detail view with RSVP (Going / Interested) and a comment thread
- "Submit an event" form so students can flag something they saw on WhatsApp for admin review
- Admin panel (Manage events, Review suggestions, Announcements, Analytics) for people with
  edit access to the page

## How it runs
This file is built for Claude.ai's Artifact runtime — it uses `window.claude.use("db")` for
shared, persistent data (events, RSVPs, comments, suggestions, announcements) and
`window.claude.use("user")` to tell admins (anyone with "Can edit" access) apart from students.
Opening `index.html` directly in a plain browser (outside claude.ai) will show the page, but
those two calls will resolve to nothing, so no data will load or save.

To use it as intended, keep it published as a claude.ai Artifact and share that link — don't
just distribute this HTML file to run standalone.
